﻿<?php

return array(

  'lng.test' => 'Example de texte',

);
