﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>view</title>
</head>

<body>

<h1><?=$data['columns']['title'];?></h1>

<h4><?=$data['columns']['content'];?></h4>

</body>
</html>