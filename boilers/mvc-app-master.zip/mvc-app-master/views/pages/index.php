﻿<?php

   ?>
    <div class="pages-list">
   <?php
      foreach($data['pages_list'] as $page){
         echo $page['title'] . "<br>";
      }
   ?>
    </div>
   <?php