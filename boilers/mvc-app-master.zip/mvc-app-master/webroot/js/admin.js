// JavaScript Document

function confirm_delete(){

 if(confirm("Delete this item")){
	 
	 return true;
	 
 }else{

	 return false;
	 
 }

}