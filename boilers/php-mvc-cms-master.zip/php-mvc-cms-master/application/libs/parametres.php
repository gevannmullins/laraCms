<?php
class Parametres {
	protected static $is_backend = false;
}