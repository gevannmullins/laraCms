<head>
<link href="<?php echo URL; ?>public/css/admin/style.css" rel="stylesheet">
<link href="<?php echo URL; ?>public/css/admin/codemirror.css" rel="stylesheet">
<!-- JavaScript -->
<script src="<?php echo URL; ?>public/js/admin/codemirror.js"></script>
<script src="<?php echo URL; ?>public/js/admin/matchbrackets.js"></script>
<script src="<?php echo URL; ?>public/js/admin/htmlmixed.js"></script>
<script src="<?php echo URL; ?>public/js/admin/xml.js"></script>
<script src="<?php echo URL; ?>public/js/admin/javascript.js"></script>
<script src="<?php echo URL; ?>public/js/admin/css.js"></script>
<script src="<?php echo URL; ?>public/js/admin/clike.js"></script>
<script src="<?php echo URL; ?>public/js/admin/php.js"></script>
</head>
<body>
<div align="center" class="container">
  <h3>Admin panel</h3>
<table>
<tr>
  <td width="80"><a href="<?php echo URL; ?>admin/">index</a></td>
  <td width="80"><a href="<?php echo URL; ?>admin/views">views</a></td>
  <td width="80"><a href="<?php echo URL; ?>admin/controllers">controllers</a></td>
  <td width="80"><a href="<?php echo URL; ?>admin/models">models</a></td>
  <td width="80"><a href="<?php echo URL; ?>admin/config">config</a></td>
  <td width="80"><a href="<?php echo URL; ?>admin/libs">libs</a></td>
  <td width="80"><a href="<?php echo URL; ?>admin/module">modules</a></td>
  <td width="80"><a href="<?php echo URL; ?>admin/logout">logout</a></td>
</tr>
</table>
</div>