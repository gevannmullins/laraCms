<?php
class login extends Controller_modules 
{
	
	public function __construct() {
		echo "created login module";
	}

}
?>