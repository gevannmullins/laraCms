@extends('layouts.admin')
@section('content')
   <h1 class="text-center">Oops! Page Not Found</h1>
@stop